@extends('layouts.admin')
@section('contents')
<div class="container-fluid mt-3">  
    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">
                    <h4 class="card-title" style="font-weight:bold;">Sampel Hasil Antigen</h4>
                </div>
                <div class="card-body">
                  <ul class="nav nav-tabs small justify-content-end" role="tablist">
                    <li class="nav-item"><a style="background-color:#668cff;color:#ffffff;" class="nav-link active" data-toggle="tab" href="#tab1" role="tab">Sample Antigen</a></li>
                    <li class="nav-item"><a class="nav-link" data-toggle="tab" href="#tab2" role="tab">Antigen Periode</a></li>
                  </ul>
                  <br/>
                  <div class="table-responsive">
                    <table id="dataRiwayatTindakan" class="table table-bordered table-striped ">
                        <thead>
                            <tr class="text-center bg-secondary">
                                <th style="width: 70px;background-color:#60b577;" class="text-light">NO.</th>
                                <th class="text-light" style="background-color:#60b577">NO. TRANSAKSI</th>
                                <th class="text-light" style="background-color:#60b577;">NIK/ PASSPORT</th>
                                <th class="text-light" style="background-color:#60b577;">NAMA PASIEN</th>
                                <th class="text-light" style="background-color:#60b577;">JENIS TINDAKAN</th>
                                <th class="text-light" style="background-color:#60b577;">NAMA FASKES</th>
                                <th class="text-light" style="background-color:#60b577;">TANGGAL TINDAKAN</th>
                                <th class="text-light" style="background-color:#60b577;">WAKTU SAMPEL</th>
                                <th class="text-light" style="background-color:#60b577;">HASIL TES</th>
                                <th style="width: 20%;background-color:#60b577;" class="text-light">AKSI</th>  
                            </tr>
                        </thead>
                        <tbody>                         
                          @if (!empty($hasilAntigensFaskes))
                            @foreach($hasilAntigensFaskes as $item)
                          <tr>
                              <td>{{$loop->iteration}}.</td>
                              <td style="text-align:center;">{{$item->transaksiID}}</td>
                              <td>{{$item->nik}}</td>
                              <td>{{$item->namaPasien}}</td>
                              <td>{{$item->namaTindakan}}</td>
                              <td>{{$item->name_outlet}}</td>
                              <td>{{$item->tglTindakan}}</td>
                              <td>{{$item->sampleTime}}</td>
                              <td>
                                
                              </td>
                              <td style="text-align:center;">
                               
                                                                                 
                              </td>
                            </tr>
                            @endforeach
                          @endif
                        </tbody>
                    </table>
                  </div>
                </div>
                <!--end of class card-body-->
            </div>
            <!--end of class card-->
        </div>
        <!--end of col-md-12-->
    </div>
    <!--end of class row-->
</div>
<!--end of class="container-fluid mt-3"-->

<script>
  $(document).on("click",'#btn_hapus_outlet', function (e) {  
   const id_ot= $(this).data('idtarget');
    $('#otletID').val(id_ot);
  });
      $('#dataRiwayatTindakan').DataTable({
        "responsive": true,
        "autoWidth": false,
        "lengthChange": false,
        "pageLength": 10,
        "order": [
          [0, "asc"],
        ],
        buttons: [
          { extend: 'excel',footer: true,},
          { extend: 'pdf',footer: true, }
         
        ]
      }).buttons().container().appendTo('#dataLaporanTindakan_wrapper .col-md-6:eq(0)'); 
</script>

@endsection